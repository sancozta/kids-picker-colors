### Picker Colors

É uma extensão feita para o Google Chorme com o objetivo de capturar sutilmente a cor do pixer em que o usuário clicar ! O resultado é retornado em formado hexadecimal ou RBG, fica a escolha do usuário ! O código hexadecimal é copiado automaticamente para a área de transferência para ser utilizado rapidamente.